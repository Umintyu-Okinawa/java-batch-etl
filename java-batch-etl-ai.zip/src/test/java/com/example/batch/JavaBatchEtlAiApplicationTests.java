package com.example.batch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaBatchEtlAiApplicationTests {

	@Test
	void contextLoads() {
	}

}
